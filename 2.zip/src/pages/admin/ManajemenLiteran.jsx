import { useEffect, useState, useMemo } from "react";
import {
  MdCheckCircle,
  MdCancel,
  MdSearch,
  MdSave,
  MdWarningAmber,
  MdStorefront,
  MdRefresh,
  MdClose,
  MdLock,
} from "react-icons/md";
import api from "../../services/api";
import { findOutletUtama } from "../../utils/outletUtama";

export default function ManajemenLiteran() {
  const [menus, setMenus] = useState([]);
  const [stocks, setStocks] = useState([]);
  const [outlets, setOutlets] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [notice, setNotice] = useState({ type: "", text: "" });
  const [editingNotes, setEditingNotes] = useState({});

  const showNotice = (type, text) => {
    setNotice({ type, text });
    setTimeout(() => setNotice({ type: "", text: "" }), 3500);
  };

  const toArray = (response) => {
    if (Array.isArray(response?.data)) return response.data;
    if (Array.isArray(response?.data?.data)) return response.data.data;
    return [];
  };

  const getErrorMessage = (error, fallback) => {
    const message = error?.response?.data?.message;
    if (message) return message;
    return fallback;
  };

  const fetchData = async () => {
    try {
      setLoading(true);
      const [menuRes, stockRes, outletRes] = await Promise.all([
        api.get("/admin/menus"),
        api.get("/public/stocks"),
        api.get("/public/outlets"),
      ]);
      const allMenus = toArray(menuRes);
      const allStocks = toArray(stockRes);
      const allOutlets = toArray(outletRes);

      const literanMenus = allMenus.filter(
        (m) => m.category === "Literan" || (m.name || "").toLowerCase().includes("literan")
      );

      setMenus(literanMenus);
      setStocks(allStocks);
      setOutlets(allOutlets);

      const notes = {};
      literanMenus.forEach((m) => {
        const stock = allStocks.find((s) => s.menu_id === m.id || s.menu?.id === m.id);
        notes[m.id] = stock?.note || "";
      });
      setEditingNotes(notes);
    } catch (error) {
      showNotice("error", getErrorMessage(error, "Gagal mengambil data produk literan."));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const outletUtama = useMemo(() => findOutletUtama(outlets), [outlets]);

  const filteredMenus = useMemo(() =>
    menus.filter((m) => (m.name || "").toLowerCase().includes(search.toLowerCase()))
  , [menus, search]);

  const totalAvailable = useMemo(() =>
    menus.filter((m) => {
      const s = stocks.find((s) => s.menu_id === m.id || s.menu?.id === m.id);
      return !s || (s.stock_status || s.stockStatus || "Tersedia") === "Tersedia";
    }).length
  , [menus, stocks]);

  const handleToggleStatus = async (menuId, currentStatus) => {
    if (!outletUtama) { showNotice("error", "Outlet utama tidak ditemukan."); return; }
    const nextStatus = currentStatus === "Tersedia" ? "Tidak Tersedia" : "Tersedia";
    const existing = stocks.find((s) => s.menu_id === menuId || s.menu?.id === menuId);
    try {
      const payload = {
        outlet_id: outletUtama.id,
        menu_id: menuId,
        rider_id: null,
        stock_status: nextStatus,
        note: editingNotes[menuId] || "",
      };
      if (existing) await api.put(`/stocks/${existing.id}`, payload);
      else await api.post("/stocks", payload);
      showNotice("success", `Status diubah → ${nextStatus}`);
      fetchData();
    } catch (error) {
      showNotice("error", getErrorMessage(error, "Gagal mengubah status."));
    }
  };

  const handleSaveNote = async (menuId) => {
    if (!outletUtama) { showNotice("error", "Outlet utama tidak ditemukan."); return; }
    const existing = stocks.find((s) => s.menu_id === menuId || s.menu?.id === menuId);
    const currentStatus = existing?.stock_status || existing?.stockStatus || "Tersedia";
    try {
      const payload = {
        outlet_id: outletUtama.id,
        menu_id: menuId,
        rider_id: null,
        stock_status: currentStatus,
        note: editingNotes[menuId] || "",
      };
      if (existing) await api.put(`/stocks/${existing.id}`, payload);
      else await api.post("/stocks", payload);
      showNotice("success", "Catatan berhasil disimpan.");
      fetchData();
    } catch (error) {
      showNotice("error", getErrorMessage(error, "Gagal menyimpan catatan."));
    }
  };

  return (
    <div className="min-h-screen px-4 py-6 sm:px-6 lg:px-8 text-white overflow-x-hidden">
      {/* Header */}
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.3em] text-emerald-300">
            Admin Only
          </p>
          <h1 className="mt-1 text-2xl font-black tracking-tight sm:text-3xl flex items-center gap-2">
            <MdStorefront className="text-emerald-400 shrink-0" />
            Manajemen Produk Literan
          </h1>
          <p className="mt-1 text-xs text-slate-400 sm:text-sm">
            Kelola ketersediaan produk literan untuk Outlet Utama · Rider tidak dapat mengakses halaman ini
          </p>
        </div>
        <button
          onClick={fetchData}
          disabled={loading}
          className="flex items-center gap-1.5 self-start sm:self-auto rounded-full bg-white/10 px-4 py-2 text-xs font-bold text-slate-200 transition hover:bg-white/20 disabled:opacity-50"
        >
          <MdRefresh className={`text-base ${loading ? "animate-spin" : ""}`} />
          Refresh
        </button>
      </div>

      {/* Stats + Search Row */}
      <div className="mb-6 flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        {/* Stats Chips */}
        <div className="flex gap-3 flex-wrap">
          <div className="rounded-2xl bg-[#103c2e] px-5 py-3 flex items-center gap-3">
            <MdStorefront className="text-emerald-400" />
            <div>
              <p className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400">Total Literan</p>
              <p className="text-xl font-black">{menus.length}</p>
            </div>
          </div>
          <div className="rounded-2xl bg-[#103c2e] px-5 py-3 flex items-center gap-3">
            <MdCheckCircle className="text-emerald-400" />
            <div>
              <p className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400">Tersedia</p>
              <p className="text-xl font-black text-emerald-400">{totalAvailable}</p>
            </div>
          </div>
          <div className="rounded-2xl bg-[#103c2e] px-5 py-3 flex items-center gap-3">
            <MdCancel className="text-red-400" />
            <div>
              <p className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400">Tidak Tersedia</p>
              <p className="text-xl font-black text-red-400">{menus.length - totalAvailable}</p>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="flex items-center gap-2 rounded-2xl bg-white/10 px-4 py-2.5 w-full sm:w-auto sm:min-w-[220px]">
          <MdSearch className="text-slate-400 shrink-0" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari produk literan..."
            className="w-full bg-transparent text-sm text-white outline-none placeholder:text-slate-500"
          />
          {search && (
            <button onClick={() => setSearch("")} className="text-slate-400 hover:text-white">
              <MdClose className="text-sm" />
            </button>
          )}
        </div>
      </div>

      {/* Info Banner */}
      <div className="mb-6 rounded-2xl bg-[#0d3a2a] border border-emerald-900/60 p-4 flex items-start gap-3">
        <MdLock className="text-emerald-400 text-lg shrink-0 mt-0.5" />
        <p className="text-xs leading-5 text-slate-300">
          <span className="font-black text-white">Produk Literan hanya dikelola Admin.</span>{" "}
          Rider tidak dapat melihat atau mengubah status literan. Perubahan status di halaman ini
          langsung ditampilkan di halaman pelanggan.
        </p>
      </div>

      {/* Notice */}
      {notice.text && (
        <div className={`mb-5 rounded-2xl px-4 py-3 text-xs font-bold flex items-center gap-2 ${
          notice.type === "success"
            ? "bg-emerald-500/20 text-emerald-200 border border-emerald-500/30"
            : "bg-red-500/20 text-red-200 border border-red-500/30"
        }`}>
          <MdWarningAmber className="text-lg shrink-0" />
          {notice.text}
        </div>
      )}

      {/* Loading */}
      {loading && menus.length === 0 && (
        <div className="rounded-3xl bg-[#103c2e] p-12 text-center text-slate-300 text-sm">
          Memuat data produk literan...
        </div>
      )}

      {/* Empty */}
      {!loading && filteredMenus.length === 0 && (
        <div className="rounded-3xl bg-[#103c2e] p-12 text-center text-slate-300 text-sm">
          {search ? `Produk "${search}" tidak ditemukan.` : "Belum ada produk literan di database."}
        </div>
      )}

      {/* Product Cards Grid */}
      {filteredMenus.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-5">
          {filteredMenus.map((menu) => {
            const stock = stocks.find(
              (s) => s.menu_id === menu.id || s.menu?.id === menu.id
            );
            const status = stock?.stock_status || stock?.stockStatus || "Tersedia";
            const isAvailable = status === "Tersedia";
            const lastUpdate = stock?.updated_at || stock?.updatedAt;

            return (
              <div
                key={menu.id}
                className={`rounded-3xl p-5 sm:p-6 flex flex-col gap-4 border transition-all duration-200 ${
                  isAvailable
                    ? "bg-[#103c2e] border-white/5"
                    : "bg-[#2a1010] border-red-900/40"
                }`}
              >
                {/* Product Header */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <h3 className="text-base font-black leading-tight">{menu.name}</h3>
                    <p className="text-xs text-emerald-300 mt-1">Literan · Outlet Utama</p>
                  </div>
                  {/* Toggle Button */}
                  <button
                    onClick={() => handleToggleStatus(menu.id, status)}
                    className={`shrink-0 flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-black border transition-all ${
                      isAvailable
                        ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30 hover:bg-red-500/20 hover:text-red-300 hover:border-red-500/30"
                        : "bg-red-500/20 text-red-300 border-red-500/30 hover:bg-emerald-500/20 hover:text-emerald-300 hover:border-emerald-500/30"
                    }`}
                    title="Klik untuk toggle status"
                  >
                    {isAvailable ? <MdCheckCircle /> : <MdCancel />}
                    {status}
                  </button>
                </div>

                {/* Description if any */}
                {menu.description && (
                  <p className="text-xs text-slate-400 leading-5">{menu.description}</p>
                )}

                {/* Note Input */}
                <div>
                  <label className="mb-1.5 block text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">
                    Catatan Stok
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={editingNotes[menu.id] ?? ""}
                      onChange={(e) =>
                        setEditingNotes((prev) => ({ ...prev, [menu.id]: e.target.value }))
                      }
                      placeholder="Stok terbatas, dl..."
                      className="flex-1 rounded-xl bg-white/10 px-3 py-2 text-xs text-white outline-none focus:bg-white/15 placeholder:text-slate-600"
                    />
                    <button
                      onClick={() => handleSaveNote(menu.id)}
                      className="rounded-xl bg-emerald-600 px-3 py-2 text-white hover:bg-emerald-500 transition flex items-center justify-center"
                      title="Simpan Catatan"
                    >
                      <MdSave className="text-sm" />
                    </button>
                  </div>
                </div>

                {/* Last Updated */}
                {lastUpdate && (
                  <p className="text-[10px] text-slate-500 text-right border-t border-white/10 pt-3">
                    Update:{" "}
                    {new Date(lastUpdate).toLocaleString("id-ID", {
                      day: "2-digit",
                      month: "short",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
