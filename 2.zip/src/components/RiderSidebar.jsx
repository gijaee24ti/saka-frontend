import {
  MdDashboard,
  MdLocalShipping,
  MdLocationOn,
  MdLogout,
} from "react-icons/md";
import { NavLink } from "react-router-dom";

export default function RiderSidebar({
  rider,
  selectedLocation,
  operationalStatus,
  formatStatusLabel,
  getOperationalColor,
  onLogout,
  onNavigate,
}) {
  const menuClass = ({ isActive }) =>
    `flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-bold transition-all duration-300 ${
      isActive
        ? "bg-white text-[#06251c]"
        : "text-slate-300 hover:bg-white/10 hover:text-white"
    }`;

  const handleNav = () => {
    if (onNavigate) onNavigate();
  };

  return (
    <aside className="relative flex h-full min-h-screen w-[280px] max-w-full flex-col overflow-hidden overflow-y-auto bg-[#061c14] px-5 py-8 text-white sm:px-6 sm:py-10">
      <div className="absolute left-0 top-0 h-4 w-full saka-checker-strip" />

      <div className="mb-8 mt-6">
        <h1 className="text-4xl font-black tracking-[0.25em] text-white sm:text-5xl">
          SAKA<span className="text-emerald-400">.</span>
        </h1>
        <div className="mt-4 inline-block rounded-xl bg-black px-4 py-2 shadow-md">
          <p className="text-xs font-black uppercase tracking-[0.22em] text-white sm:text-sm">
            On The Road
          </p>
        </div>
      </div>

      {rider && (
        <div className="mb-6 rounded-2xl bg-[#0d3a2a] p-4">
          <p className="text-[10px] font-black uppercase tracking-[0.25em] text-emerald-300">
            Rider Aktif
          </p>
          <p className="mt-2 truncate text-sm font-black text-white">{rider.name}</p>
          <p className="mt-1 truncate text-xs text-slate-400">
            {rider.phone || "No HP belum diisi"}
          </p>
          <div className="mt-3 flex items-start gap-2 text-xs text-slate-300">
            <MdLocationOn className="mt-0.5 shrink-0 text-emerald-400" />
            <span className="min-w-0 break-words">
              {rider.stand || rider.location || "Belum ditentukan"}
              {selectedLocation
                ? ` · ${selectedLocation.openTime || "-"} - ${selectedLocation.closeTime || "-"}`
                : ""}
            </span>
          </div>
          {operationalStatus && (
            <div className="mt-3">
              <span
                className={`inline-flex rounded-full px-3 py-1.5 text-[10px] font-black ${getOperationalColor(
                  operationalStatus
                )}`}
              >
                {formatStatusLabel(operationalStatus)}
              </span>
            </div>
          )}
        </div>
      )}

      <nav className="flex-1">
        <p className="mb-3 px-1 text-[9px] font-black uppercase tracking-[0.3em] text-slate-500">
          Menu Rider
        </p>
        <ul className="space-y-1">
          <li>
            <NavLink to="/rider" end className={menuClass} onClick={handleNav}>
              <MdDashboard className="shrink-0 text-xl" />
              <span>Dashboard</span>
            </NavLink>
          </li>
        </ul>
      </nav>

      <div className="mt-auto pt-6">
        <div className="rounded-3xl bg-[#0d3a2a] p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white/10 text-white">
              <MdLocalShipping className="text-lg" />
            </div>
            <div className="min-w-0">
              <p className="text-[10px] font-black uppercase tracking-[0.25em] text-emerald-300">
                Panel Rider
              </p>
              <p className="mt-1 truncate text-sm font-black text-white">
                {rider?.name || "Rider Saka"}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              handleNav();
              onLogout();
            }}
            className="mt-5 flex min-h-[44px] w-full items-center justify-center gap-2 rounded-full bg-white px-4 py-3 text-sm font-black text-[#06251c] transition-all duration-300 hover:bg-emerald-100"
          >
            <MdLogout />
            Logout
          </button>
        </div>

        <div className="mt-6">
          <p className="text-xs font-bold text-slate-500">SAKA On The Road Rider</p>
          <p className="mt-1 text-xs text-slate-600">© 2026 All Right Reserved</p>
        </div>
      </div>
    </aside>
  );
}
